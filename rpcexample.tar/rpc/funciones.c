/**
 * nombre: funciones.c
 * objetivo: muestra las funciones en ansi c
 * autor:
 * Fecha: 6/08/2020
 */

# include <stdio.h>
# include <string.h>

/**
 * Función para regresar un mensaje
 */

char* getMessage()
{
    return "hola mundo";
}

int suma(int n1, int n2)
{
    return n1+n2;
}


int resta(int n1, int n2)
{
    return n1-n2;
}

int main()
{
    printf("El mensaje es: %s\n", getMessage());
    printf("La suma es :%d\n", suma(2,5) );
    printf("La resta es :%d\n", resta(22,-5) );
    return 0;
}