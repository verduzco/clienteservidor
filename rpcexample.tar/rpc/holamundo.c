/**
Nombre: holamundo.c
Objetivo: mi primer programa en ansi c
Autor:
Fecha: 6 de agosto de 2020
*/

#include <stdio.h>

int main() 
{
  printf("Hola mundo peludo\n");
  return 0;

}
